export class ApiConstants {
  static readonly APP_BASEURL = 'https://dummyjson.com/';
}
