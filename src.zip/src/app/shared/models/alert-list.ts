export interface AlertList {
    wellName: string;
    alertLevel: string;
    date: Date;
    desc: string;
    status: string;
    category: string;
    action: string;
}