import { Component } from '@angular/core';

@Component({
  selector: 'app-create-gateway-innertabs',
  templateUrl: './create-gateway-innertabs.component.html',
  styleUrls: ['./create-gateway-innertabs.component.scss']
})
export class CreateGatewayInnertabsComponent {

}
