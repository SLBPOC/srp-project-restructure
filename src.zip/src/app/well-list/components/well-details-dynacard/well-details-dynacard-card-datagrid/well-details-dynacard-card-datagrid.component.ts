import { Component } from '@angular/core';

@Component({
  selector: 'app-well-details-dynacard-card-datagrid',
  templateUrl: './well-details-dynacard-card-datagrid.component.html',
  styleUrls: ['./well-details-dynacard-card-datagrid.component.scss']
})
export class WellDetailsDynacardCardDatagridComponent {

}
