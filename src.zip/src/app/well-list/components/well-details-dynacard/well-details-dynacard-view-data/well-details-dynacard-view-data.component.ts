import { Component } from '@angular/core';

@Component({
  selector: 'app-well-details-dynacard-view-data',
  templateUrl: './well-details-dynacard-view-data.component.html',
  styleUrls: ['./well-details-dynacard-view-data.component.scss']
})
export class WellDetailsDynacardViewDataComponent {

}
